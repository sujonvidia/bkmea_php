<?php
global $_DOCMAN;

 //echo "DOCMan v".$_DOCMAN->getCfg('docman_version');
 //echo "- 2003 - 2005 The DOCMan Development Team - <a href='http://www.mambodocman.com/' target='_blank'>www.mambodocman.com</a>";
?>
